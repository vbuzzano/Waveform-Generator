package net.sourceforge.jaad.mp4.boxes.impl;

/**
* Some box types needed to extract all audio data from an MP4 stream.
*/