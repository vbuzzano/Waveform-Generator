package net.sourceforge.jaad.mp4;

import java.io.IOException;

public class MP4Exception extends IOException {

	public MP4Exception(String message) {
		super(message);
	}
}
