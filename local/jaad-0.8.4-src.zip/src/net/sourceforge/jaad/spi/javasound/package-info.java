package net.sourceforge.jaad.spi.javasound;

/**
 * SPI implementation for Java Sound.
 * When in CLASSPATH, this can be used by all applications and top-level-APIs
 * that use Java Sound.
 */
