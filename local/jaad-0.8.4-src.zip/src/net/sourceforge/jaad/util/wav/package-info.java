package net.sourceforge.jaad.util.wav;

/**
* Utility package for writing raw PCM data to a wave file.
*/
